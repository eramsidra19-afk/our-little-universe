OUR LITTLE UNIVERSE — VOL. 02

1. Open index.html in a browser to preview the website.
2. Personalise the timeline, notes, reasons, quiz questions, songs and letter in index.html.
3. To publish free with GitHub Pages:
   - Create/sign in to a GitHub account.
   - Create a new public repository (for example: our-little-universe).
   - Upload index.html to the repository's main/root folder.
   - Open Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch.
   - Select branch: main, folder: /(root), then Save.
   - Wait for GitHub to publish and use the link shown in the Pages section.

Notes:
- This is a static website; it does not need a paid API or database.
- Photo previews are local to the visitor's browser and are not uploaded or shared.
- Bucket-list checkboxes save in that browser only.
- The music section is a placeholder for links; no copyrighted music is bundled.
- Replace the sample reasons/messages with your own words before sharing.
